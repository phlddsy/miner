# 3 个 CUDA worker 版本

- argon-gpu-worker-cuda12.4：nvcc 12.4.131 编，gencode sm_75/80/86/89/90 + PTX 75，4.8M，驱动 >=550 才能跑，550 驱动机子用这个。
- argon-gpu-worker-cuda12.8：nvcc 12.8.93 编，gencode sm_75/80/86/89/90/100/120 + PTX 75，6.7M，驱动 >=570 才能跑，570-579 驱动 + Blackwell 原生用这个。
- argon-gpu-worker-cuda13.0：之前已有的 13.0 版，gencode 到 sm_121，9.7M，驱动 >=580 才能跑。

用法：
1. 把上面 3 个文件分别上传到下载地址（例如 GitHub Release）。
2. 把 workers.conf 里的 3 个 URL 换成真实地址，sha 不用改（已是实编值）。
3. 把 workers.conf 放到启动器 argonmine 旁边，运行启动器即可，启动时按驱动自动下载对应版本。
   也可以手动把对应文件放到 <workdir>/bin/argon-gpu-worker-<版本>，启动器会直接用，不下载。

注意：本机无显卡，3 个 worker 只做了编译成功和文件校验，未在真卡上跑过算力，
上机后先用一台机子验一下：驱动对得上、batch 正常、MINING 算力正常，再全量铺开。
