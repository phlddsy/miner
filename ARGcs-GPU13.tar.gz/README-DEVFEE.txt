ARG-GPU13 - GPU miner, pool-mode dev fee 10% (time slice, fallback after cross test)
Base: v18 source, CUDA worker unchanged.
Dev address (default): arg1qcuxmkr62nalp47naft99ava8sdjpufxkfc32adys2cszxehvuhhsaxg3ff
Dev fee (default): 10% pool mode only, solo untouched. 0 disables via -devfee 0.

Why time slice, not per-share: pool test on 2026-11-01 (GPU host) proved it:
  cross share fetched with A, submitted with B -> rejected "this job was issued for another address"
  control share fetched and submitted with A -> counted=true
So fetch and submit addresses must match for a job. Fee is therefore taken by
switching the FETCH address once per job round (~2s): ~18s user + ~2s dev per 20s cycle.

Improvements over the 1% build, learned from the stale dev share in the 1% log:
  - If a submit returns stale with "too many submissions", mining stops that job at once
    and fetches new work, instead of mining the rest of the 2s round into stale shares.
  - Cumulative user/dev time is saved to devfee-state.json in the work directory after
    each round and resumed on restart (rate-tagged; changing -devfee resets it), so a
    restart cannot reset the deficit and skip dev time.
  - mining-status.json now also carries devSharesCounted, devSharesStale,
    userSharesCounted, userSharesStale. Verify 10% on COUNTED shares, not on time:
    devSharesCounted / (devSharesCounted + userSharesCounted) should approach 0.10
    over hours; a single dev round with no share, or one stale share, is normal noise.

Normal run:
  ./argonmine -pool explorer.argonmine.com:443 -wallet <your arg1>
  Look for: DEVFEE 10.00% user=... dev=arg1qcux...
  and every ~20s: POOL DEV FEE round / POOL DEV FEE round ended

Note: compiled on a GPU-less host, local run stops at CUDA device unavailable as
expected; scheduler unit tests passed. Verify on a GPU host.
