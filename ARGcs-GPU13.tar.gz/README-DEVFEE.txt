ARG-GPU13 - GPU miner with pool-mode dev fee (base: argonmine-single v18 source, worker unchanged)
Dev address (default): arg1qcuxmkr62nalp47naft99ava8sdjpufxkfc32adys2cszxehvuhhsaxg3ff
Dev fee (default): 1% pool mode only, solo mode untouched. 0 disables.
How it works: controller switches the pool accounting address once per job round (~2s).
Worker only hashes, never sees either address. No restart needed to switch user<->dev in-run;
changing the compiled-in dev address needs a rebuild.

Normal run (1%):
  ./argonmine -pool explorer.argonmine.com:443 -wallet <your arg1>
  Look for log: DEVFEE 1.00% user=... dev=arg1qcux...
  and, about every ~3-4 min, POOL DEV FEE round: shares this round credit dev=...
  mining-status.json carries effectiveAddress, devfeePercent, devSeconds, userSeconds.

Quick test (see dev rounds in ~1 min, do NOT use for production):
  ./argonmine -pool explorer.argonmine.com:443 -wallet <your arg1> -devfee 50
  Then check pool dashboard for dev address shares, and for your address shares.
  A dev round with no share is normal at 1%; at 50% dev rounds alternate frequently.
  Re-run without -devfee for the 1% production default.

Note: this build was compiled on a GPU-less host, so local verification stopped at
"CUDA device unavailable" as expected; unit tests for the scheduler passed.
Verify on a GPU host.
