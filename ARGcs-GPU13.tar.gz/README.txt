异步版（2026-11-01）
- 异步：每卡独立循环，不等最慢卡
- 命令：./argonmine -pool explorer.argonmine.com:443 -wallet arg1qnw4uk5lxpzv2q8msfjlxyskpwxrjreamz7tqcrmcxswlh498f2pqa6y4dx
- MINING 行带 ASYNC，mining-status.json mode=pool-async
