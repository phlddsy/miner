ARG-GPU13-ASYNC-NODEVFEE 异步无抽水测试版（2026-11-01）
- 异步：每卡独立循环，跑完一批立刻跑下一批，不等最慢卡、不等控制器逐个验完其他卡的份额
- 无抽水：单活、全部份额归用户钱包，-devfee 参数在本版被忽略，启动应见 DEVFEE off
- 控制器每 2 秒换活（或 stale 时立即换活），每卡在批边界切换新活，正在跑的批不中断
- MINING 行带 ASYNC，mining-status.json mode=pool-async-nodevfee，devfeePercent=0
- 本版只用于验证多卡扩展性：单卡、4 卡、6 卡各跑 1 分钟对比单卡算力，确认后再决定是否把批次抽水加回异步版
- 命令：./argonmine -pool explorer.argonmine.com:443 -wallet arg1qnw4uk5lxpzv2q8msfjlxyskpwxrjreamz7tqcrmcxswlh498f2pqa6y4dx
- 多卡：默认 auto 检全部卡，也可用 -devices 0,1,2,3,4,5 指定
