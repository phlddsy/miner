argonmine CPU 池子版（Linux x86_64，纯 Go 编译，无需显卡、无需 CUDA、无驱动版本要求）
构建：2026-11-01，源码 cmd/argonmined（pool.go 新增，GPU 控制器 v18 未动），Go 1.27.3
文件：argonmined（14M）

池子模式（新增，不用本地节点、不用等同步）：
  ./argonmined -pool explorer.argonmine.com:443 -wallet arg1<你的地址>
  # 默认线程数 = CPU核心数-1；共享主机请显式填小一点的 -threads
  ./argonmined -pool explorer.argonmine.com:443 -wallet arg1<你的地址> -threads 32
  nohup ./argonmined -pool explorer.argonmine.com:443 -wallet arg1<你的地址> > argonmined-pool.log 2>&1 &

solo 模式（不变，仍需本地节点同步）：
  ./argonmined -mine arg1<你的地址>
  # -pool 和 -mine 不能同时用；-pool 必须配 -wallet

池子模式说明：
  - 工作从池子 REST API 拿，校验与 GPU 版完全一致（coinbase、merkle、bits、shareTarget），校验不过的工作不挖。
  - 哈希用与 solo 相同的 CPU Argon2id，哈希 <= shareTarget 交份额，<= blockTarget 即块（池子代提交）。
  - 份额提交失败只记日志不杀矿工；队列满了丢份额并计数。
  - 算力还是 CPU 量级：128 核约 2000 H/s，现在 shareTarget 约 384k 哈希一个份额，约 3 分钟一个份额；池子按份额记账，满 0.1 ARG 才付，成熟 100 块后到账。
  - 日志每 10 秒一行：MINING <算力> hashes=... shares=... completed=... dropped=... stale=... height=... threads=... POOL=true

注意：只用公开的 arg1 收款地址，不交助记词/私钥。
