ARG-GPU13-TEST - cross-address submit test build (NOT production, do not use for long mining)
Base: v18 + 1% time-slice dev fee (unchanged) + new -test-cross-address mode.
Dev address default: arg1qcuxmkr62nalp47naft99ava8sdjpufxkfc32adys2cszxehvuhhsaxg3ff

Run on a GPU host (this mode needs CUDA, it will not run on a GPU-less host):
  ./argonmine -pool explorer.argonmine.com:443 -wallet <your arg1> -test-cross-address
  (dev address defaults to the one above; add -dev-address <other> only if you want a different dev address for the test)

What it does, in order:
  1. Fetches pool work with YOUR wallet, mines until 1 share is found, submits it with the DEV address.
  2. Fetches fresh work, mines a 2nd share, submits it with YOUR wallet as control.
  3. Prints CROSS TEST VERDICT and exits. It does not continue mining.

Read the verdict, not just one line:
  ACCEPTED   - cross counted=true and control counted=true -> per-share rotation is viable, next step is to build 10% per-share.
  REJECTED   - cross counted=false but control counted=true -> pool rejects cross-address submits, fall back to per-round time slice.
  INCONCLUSIVE - control also did not count (stale job / pool issue) -> rerun, do not treat as rejected.
Also check the pool dashboard for both addresses: cross share should appear under dev, control under yours.

Timeout: 10 minutes per share. If no share in 10 min, it reports inconclusive (rig too slow / share difficulty too high), not a rejection.
