# ARG GPU 抽水异步版 - worker 分离版

启动器 argonmine 不再内嵌 CUDA worker，只内嵌节点和控制器。
worker 按驱动版本从 workers.conf 下载，包里只放配置文件，不用为每个 CUDA 版本各打一包。

## 首次使用（必须先填 workers.conf）

1. 把 3 个 worker 文件分别上传到下载地址（例如 GitHub Release）：
   - cuda12.4：驱动 <570 的机子用（550 驱动那台）
   - cuda12.8：驱动 570-579 的机子用，Blackwell 原生
   - cuda13.0：驱动 >=580 的机子用；如果 workers.conf 里没有这一行，>=580 自动回落到 cuda12.8
2. 编辑 workers.conf，把每行的 URL 换成真实下载地址，sha256 换成 `sha256sum <worker文件>` 的结果。
   cuda13.0 现有 worker 的 sha 已填好：1c4cf350f173d1f327d4ab0b49138117ce835230fdea27c6d5e3b2a7d039aeb2
   上传的就是之前那个 9.7M 的 worker 文件时，sha 就用这个，不用重算。
3. 运行：
   tar -xzf ARG-GPU-ASYNC-DEVFEE-WORKER-DL.tar.gz
   ./argonmine -pool explorer.argonmine.com:443 -wallet arg1qnw4uk5lxpzv2q8msfjlxyskpwxrjreamz7tqcrmcxswlh498f2pqa6y4dx

启动时会自动：查驱动 -> 选版本 -> 看本地 bin/ 有没有且 sha 对得上 -> 没有才下载 -> 验 sha -> 跑矿。
第二次启动已有 worker 就不下载。离线机子可以手动把 worker 放到 <workdir>/bin/argon-gpu-worker-<版本>，
或 bin/argon-gpu-worker（无 sha 配置时认这个），启动器会直接用，不下载。

## 强制版本

默认 auto 按驱动选。想强制某版：
  ./argonmine -pool ... -wallet ... -cuda-version cuda12.8
  ./argonmine -pool ... -wallet ... -workers-conf /path/to/workers.conf

## 注意

- 本包仍是抽水异步版：日志无抽水行，MINING 只计用户部分算力，抽水验证看池子第二地址。
- AriaPool stratum 池（arg.ariabrain.com:3360）尚未接入：本包的池地址解析已修，不会再把 stratum+tcp://
  错拼成 https://stratum+tcp//...，但 stratum 挖矿客户端仍在等活格式确认，暂不要用本包指 Aria 池。
